package com.alathaniraq.tv.util

import android.content.Context

object Prefs {
    private const val FILE = "al_athan_iraq_prefs"
    private const val KEY_DISTRICT = "selected_district_id"
    private const val KEY_SUB_DISTRICT = "selected_sub_district_id"
    private const val KEY_MOSQUE_NAME = "mosque_name"

    fun getDistrictId(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_DISTRICT, null) ?: com.alathaniraq.tv.data.IraqRegions.defaultDistrict().id
    }

    fun setDistrictId(context: Context, districtId: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_DISTRICT, districtId).remove(KEY_SUB_DISTRICT).apply()
    }

    /** Sub-district is optional — most districts don't have any defined. Null clears it. */
    fun getSubDistrictId(context: Context): String? {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_SUB_DISTRICT, null)
    }

    /** Sets both together — a sub-district always belongs to a specific district. */
    fun setDistrictAndSubDistrict(context: Context, districtId: String, subDistrictId: String?) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val editor = sp.edit().putString(KEY_DISTRICT, districtId)
        if (subDistrictId != null) editor.putString(KEY_SUB_DISTRICT, subDistrictId) else editor.remove(KEY_SUB_DISTRICT)
        editor.apply()
    }

    /** Display name for the mosque shown at the top of the home screen. Editable per-install. */
    fun getMosqueName(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_MOSQUE_NAME, null) ?: context.getString(com.alathaniraq.tv.R.string.default_mosque_name)
    }

    fun setMosqueName(context: Context, name: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_MOSQUE_NAME, name).apply()
    }

    // --- Iqama offsets (minutes after adhan), editable via the Iqama settings screen ---
    // Defaults follow a common local convention; Maghrib defaults to 8 to match the
    // reference design. Adjust freely — these are just sensible starting points.
    private val DEFAULT_IQAMA_OFFSETS = mapOf(
        "fajr" to 20,
        "dhuhr" to 15,
        "asr" to 15,
        "maghrib" to 8,
        "isha" to 15
    )

    private fun iqamaKey(prayerKey: String) = "iqama_offset_$prayerKey"

    /** [prayerKey] is one of "fajr", "dhuhr", "asr", "maghrib", "isha". */
    fun getIqamaOffset(context: Context, prayerKey: String): Int {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val default = DEFAULT_IQAMA_OFFSETS[prayerKey] ?: 15
        return sp.getInt(iqamaKey(prayerKey), default)
    }

    fun setIqamaOffset(context: Context, prayerKey: String, minutes: Int) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putInt(iqamaKey(prayerKey), minutes).apply()
    }

    // --- Jumua (Friday prayer) offset in minutes after the Dhuhr adhan ---
    // Dashboard home screen shows this as a distinct "Jumua" time next to Shuruk.
    // Two modes, set from Settings > Jumua (Friday Prayer) Times Adjustment:
    //  1. "Match Dhuhr" — Jumua is shown exactly the same as Dhuhr.
    //  2. "Adjust +/- minutes" — Jumua = Dhuhr + offset, where offset can be negative
    //     (Jumua called before Dhuhr's adhan time) or positive (called after).
    private const val KEY_JUMUA_OFFSET = "jumua_offset"
    private const val KEY_JUMUA_MATCH_DHUHR = "jumua_match_dhuhr"
    private const val DEFAULT_JUMUA_OFFSET = 10

    fun getJumuaOffset(context: Context): Int {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getInt(KEY_JUMUA_OFFSET, DEFAULT_JUMUA_OFFSET)
    }

    fun setJumuaOffset(context: Context, minutes: Int) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putInt(KEY_JUMUA_OFFSET, minutes).apply()
    }

    /** True = Jumua is shown exactly matching Dhuhr, ignoring the offset above. */
    fun getJumuaMatchDhuhr(context: Context): Boolean {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getBoolean(KEY_JUMUA_MATCH_DHUHR, false)
    }

    fun setJumuaMatchDhuhr(context: Context, match: Boolean) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putBoolean(KEY_JUMUA_MATCH_DHUHR, match).apply()
    }

    // --- Home screen design: which layout MainActivity/DashboardMainActivity shows ---
    private const val KEY_HOME_MODE = "home_screen_mode"
    const val HOME_MODE_CLASSIC = "classic"
    const val HOME_MODE_DASHBOARD = "dashboard"

    /** Dashboard is the default for new installs; Classic remains available in Settings. */
    fun getHomeScreenMode(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_HOME_MODE, HOME_MODE_DASHBOARD) ?: HOME_MODE_DASHBOARD
    }

    fun setHomeScreenMode(context: Context, mode: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_HOME_MODE, mode).apply()
    }

    // --- Color scheme (Settings > Color Scheme) ---
    private const val KEY_COLOR_SCHEME = "color_scheme_id"

    fun getColorSchemeId(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_COLOR_SCHEME, "teal_gold") ?: "teal_gold"
    }

    fun setColorSchemeId(context: Context, id: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_COLOR_SCHEME, id).apply()
    }
}
