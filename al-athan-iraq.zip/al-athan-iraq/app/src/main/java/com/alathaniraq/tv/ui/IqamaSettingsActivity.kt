package com.alathaniraq.tv.ui

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.alathaniraq.tv.databinding.ActivityIqamaSettingsBinding
import com.alathaniraq.tv.databinding.ItemIqamaRowBinding
import com.alathaniraq.tv.util.Prefs

/**
 * Lets the user adjust how many minutes after each adhan the iqama is called.
 * Values are clamped to [MIN_OFFSET, MAX_OFFSET] and saved immediately on each tap,
 * so there's no separate "save" step to forget — "Done" just returns to the menu.
 *
 * Jumua (Friday prayer) has its own dedicated screen (Settings > Jumua (Friday Prayer)
 * Times Adjustment) since it has a different, richer set of options — see
 * JumuaSettingsActivity.
 */
class IqamaSettingsActivity : ComponentActivity() {

    private lateinit var binding: ActivityIqamaSettingsBinding
    private var changed = false

    private data class Row(val key: String, val label: String, val rowBinding: ItemIqamaRowBinding)
    private lateinit var rows: List<Row>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIqamaSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        rows = listOf(
            Row("fajr", getString(com.alathaniraq.tv.R.string.fajr), binding.rowFajr),
            Row("dhuhr", getString(com.alathaniraq.tv.R.string.dhuhr), binding.rowDhuhr),
            Row("asr", getString(com.alathaniraq.tv.R.string.asr), binding.rowAsr),
            Row("maghrib", getString(com.alathaniraq.tv.R.string.maghrib), binding.rowMaghrib),
            Row("isha", getString(com.alathaniraq.tv.R.string.isha), binding.rowIsha)
        )

        rows.forEach { row ->
            row.rowBinding.rowPrayerName.text = row.label
            refreshRowValue(row)

            row.rowBinding.rowMinus.setOnClickListener { adjust(row, -1) }
            row.rowBinding.rowPlus.setOnClickListener { adjust(row, 1) }
        }

        binding.doneButton.setOnClickListener { finish() }
        rows.first().rowBinding.rowMinus.requestFocus()
    }

    private fun adjust(row: Row, delta: Int) {
        val current = Prefs.getIqamaOffset(this, row.key)
        val updated = (current + delta).coerceIn(MIN_OFFSET, MAX_OFFSET)
        if (updated != current) {
            Prefs.setIqamaOffset(this, row.key, updated)
            changed = true
            refreshRowValue(row)
        }
    }

    private fun refreshRowValue(row: Row) {
        row.rowBinding.rowValue.text = "+${Prefs.getIqamaOffset(this, row.key)}"
    }

    override fun finish() {
        setResult(if (changed) Activity.RESULT_OK else Activity.RESULT_CANCELED)
        super.finish()
    }

    companion object {
        private const val MIN_OFFSET = 0
        private const val MAX_OFFSET = 60
    }
}
