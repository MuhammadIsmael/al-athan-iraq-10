package com.alathaniraq.tv.ui

import android.content.Context
import com.alathaniraq.tv.util.Prefs

/**
 * Two home screen designs share this app: Classic (MainActivity) and Dashboard
 * (DashboardMainActivity). Splash and both home activities call this to agree on
 * which one should be showing right now, based on the Settings > Change Home Screen
 * preference.
 */
object HomeScreenRouter {
    fun launcherActivityClass(context: Context): Class<*> {
        return if (Prefs.getHomeScreenMode(context) == Prefs.HOME_MODE_CLASSIC) {
            MainActivity::class.java
        } else {
            DashboardMainActivity::class.java
        }
    }
}
