package com.alathaniraq.tv.ui

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.alathaniraq.tv.databinding.ActivityHomeScreenPickerBinding
import com.alathaniraq.tv.util.Prefs

class HomeScreenPickerActivity : ComponentActivity() {

    private lateinit var binding: ActivityHomeScreenPickerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeScreenPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.optionDashboard.setOnClickListener { choose(Prefs.HOME_MODE_DASHBOARD) }
        binding.optionClassic.setOnClickListener { choose(Prefs.HOME_MODE_CLASSIC) }

        val current = Prefs.getHomeScreenMode(this)
        if (current == Prefs.HOME_MODE_CLASSIC) {
            binding.optionClassic.requestFocus()
        } else {
            binding.optionDashboard.requestFocus()
        }
    }

    private fun choose(mode: String) {
        Prefs.setHomeScreenMode(this, mode)
        setResult(Activity.RESULT_OK)
        finish()
    }
}
